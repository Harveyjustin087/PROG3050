﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CVGS_Site.Models
{
    public partial class EventLog
    {
        public EventLog()
        {
            EventRegister = new HashSet<EventRegister>();
        }

        public int EventId { get; set; }
        public string EventName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Detail { get; set; }
        public int? RegisterEventId { get; set; }

        public virtual ICollection<EventRegister> EventRegister { get; set; }
    }
}
