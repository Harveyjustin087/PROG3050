﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace CVGSValidation
{
    public class EmailAttribute : ValidationAttribute
    {
        public EmailAttribute()
        {
            ErrorMessage = "{0} is not a valid email address";
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            try
            {
                if (value == null) 
                {
                    return ValidationResult.Success;
                }
                System.Net.Mail.MailAddress convertTry = new System.Net.Mail.MailAddress(value.ToString());
            }
            catch
            {
                return new ValidationResult(string.Format(ErrorMessage, validationContext.DisplayName));
            }
            return ValidationResult.Success;
        }
    }
    public class PostalCodeAttribute : ValidationAttribute
    {
        public PostalCodeAttribute()
        {
            ErrorMessage = "Validation using library found {0} does not match the Canadian postal code pattern: A3A 3A3";
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            Regex pattern = new Regex(@"^[a-z]\d[a-z] ?\d[a-z]\d$", RegexOptions.IgnoreCase);
            if (value == null || value.ToString() == "" || pattern.IsMatch(value.ToString()))
                return ValidationResult.Success;

            return new ValidationResult(string.Format(ErrorMessage, validationContext.DisplayName));
        }
    }
    public class WordCountAttribute : ValidationAttribute
    {
        Int32 MaxWords, MinWords = 0;
        public WordCountAttribute(Int32 maxWords)
        {
            ErrorMessage = "{0} cannot be longer than {1} words.";
            MaxWords = maxWords;
        }
        public WordCountAttribute(Int32 maxWords, Int32 minWords)
        {
            ErrorMessage = "{0} cannot be less than {2} or more than {1} words.";
            MaxWords = maxWords;
            MinWords = minWords;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != null && (value.ToString().Split(' ').Length > MaxWords ||
                                  value.ToString().Split(' ').Length < MinWords))
                return new ValidationResult(
                    String.Format(ErrorMessage, validationContext.DisplayName, MaxWords, MinWords));
            else
                return ValidationResult.Success;
        }
    }
}
