﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CVGS_Site.Models
{
    public class ReCAPTCHASettings
    {
        public int ReCAPTCHA_Site_Key { get; set; }
        public int ReCAPTCHA_Secret_Key { get; set; }
    }
}
