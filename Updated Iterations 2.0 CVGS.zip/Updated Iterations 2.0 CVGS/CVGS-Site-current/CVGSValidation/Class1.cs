﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace CVGSValidation
{
    public class CVGSEmailAttribute : ValidationAttribute
    {
        public CVGSEmailAttribute()
        {
            ErrorMessage = "Not a valid email address";
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            Regex pattern = new Regex(@"^[\w]+@([\w-]+\.)+[\w-]{2,4}$", RegexOptions.IgnoreCase);
            string tmpValue = "";
            if (value != null)
            {
                tmpValue = value.ToString();
            }
            if (String.IsNullOrEmpty(tmpValue) | pattern.IsMatch(tmpValue))
                return ValidationResult.Success;
            return new ValidationResult(string.Format(ErrorMessage, validationContext.DisplayName));
        }
    }
    public class CVGSPhoneAttribute : ValidationAttribute
    {
        public CVGSPhoneAttribute()
        {
            ErrorMessage = "Not a valid phone number";
        }
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            Regex pattern = new Regex(@"^(\+\d{1,2}\s)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$", RegexOptions.IgnoreCase);
            string tmpValue = "";
            if (value != null)
            {
                tmpValue = value.ToString();
            }
            if (String.IsNullOrEmpty(tmpValue) | pattern.IsMatch(tmpValue))
                return ValidationResult.Success;
            return new ValidationResult(string.Format(ErrorMessage, validationContext.DisplayName));
        }
    }
    public static class StringManipulation
    {
        public static string EmptyAndTrim(string input)
        {
            if (input == null)
            {
                return "";
            }
            return input.Trim();
        }
    }
}
